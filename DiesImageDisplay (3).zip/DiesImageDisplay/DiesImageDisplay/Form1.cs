﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DiesImageDisplay
{
    public partial class Form1 : Form
    {
        Image[] diceImage;
        int[] dice;
        Random randomNumber;
        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            diceImage = new Image[7];
            diceImage[0] = Properties.Resources.die1;
            diceImage[1] = Properties.Resources.die2;
            diceImage[2] = Properties.Resources.die3;
            diceImage[4] = Properties.Resources.die4;
            diceImage[5] = Properties.Resources.die5;
            diceImage[6] = Properties.Resources.die6;

            dice = new int[] { 0, 1, 2, 3, 4, 5, 6 };
            randomNumber = new Random();
        }
        private void btnDisplayDice_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < dice.Length; i++)
            {
                dice[i] = randomNumber.Next(1, 5);
                pictureDice.Image = diceImage[dice[i]];
            }
           
           
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

       
    }
}
